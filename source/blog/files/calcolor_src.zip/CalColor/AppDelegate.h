//
//  AppDelegate.h
//  CalColor
//
//  Created by Lin Fan on 6/4/13.
//  Copyright (c) 2013 Lin Fan. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>
{
	IBOutlet NSPopUpButton *calendarList;
	IBOutlet NSColorWell *colorButton;
}

@property (assign) IBOutlet NSWindow *window;

- (IBAction)calendarChange:(id)sender;
- (IBAction)colorChange:(id)sender;

@end
