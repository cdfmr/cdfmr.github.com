//
//  AppDelegate.m
//  CalColor
//
//  Created by Lin Fan on 6/4/13.
//  Copyright (c) 2013 Lin Fan. All rights reserved.
//

#import "AppDelegate.h"
#import <CalendarStore/CalendarStore.h>

@implementation AppDelegate

NSArray *calendars;

- (void)dealloc
{
	[calendars release];
    [super dealloc];
}

- (void)loadCalendars
{
	calendars = [[[CalCalendarStore defaultCalendarStore] calendars] retain];
	for (CalCalendar *calendar in calendars)
	{
		[calendarList addItemWithTitle:[calendar title]];
	}
	[self calendarChange:nil];
}

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
	[[self window] center];
	[self loadCalendars];
	[[self window] makeKeyAndOrderFront:nil];
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed: (NSApplication *)app
{
	return YES;
}

- (IBAction)calendarChange:(id)sender
{
	[colorButton setColor:[[calendars objectAtIndex:[calendarList indexOfSelectedItem]] color]];
}

- (IBAction)colorChange:(id)sender
{
	CalCalendar *calendar = [calendars objectAtIndex:[calendarList indexOfSelectedItem]];
	[calendar setColor:[colorButton color]];
	[[CalCalendarStore defaultCalendarStore] saveCalendar:calendar error:nil];
}

@end
